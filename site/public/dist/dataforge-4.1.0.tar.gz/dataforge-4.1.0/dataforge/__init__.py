"""DataForge Programming Language v4.0
A revolutionary language built on Python with unique syntax and keywords.
"""

__version__ = "4.1.0"
__language__ = "DataForge"
