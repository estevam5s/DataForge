/**
 * DataForge no VS Code.
 *
 * A extensão não reimplementa nada da linguagem: ela chama a CLI e
 * desenha o resultado. Isso é o que garante que o sublinhado no editor,
 * a saída do terminal e o que quebra o CI sejam sempre a mesma coisa.
 *
 * O que ela acrescenta é o que só faz sentido dentro do editor:
 * complexidade acima de cada ação, custo ao lado de cada import, um
 * botão para rodar, e o painel de conexões.
 */

import * as vscode from 'vscode';
import { anotar } from './custo';
import { ArvoreDeConexoes, Item } from './conexoes';
import { ArvoreDeFerramentas } from './ferramentas';
import { LenteDeComplexidade, acoesDe, explicar } from './complexidade';
import { abrirCurvas, medirComplexidade } from './bigo';
import { criarProjeto } from './projetos';
import { esquecerExecutavel, exigirExecutavel, raizDe, rodar } from './dataforge';
import { Verificador } from './diagnosticos';
import * as depuracao from './depuracao';
import { iniciarServidor, reiniciarServidor, servidorAtivo } from './servidor';
import * as cmd from './comandos';
import {
  fecharTerminal,
  formatarTempo,
  medirRepetido,
  obterCanal,
  rodarEMostrarTempo,
  rodarNoTerminal,
} from './executar';
import { converterArquivo, converterPasta, converterSelecao }
  from './converter';
import { prepararIndicador, pararTudo, servidorAbrirNavegador,
         servidorIniciar, servidorParar, servidorReiniciar }
  from './kiln';
import { abrirMenu, Barra } from './barra';
import * as testes from './testes';
import * as aprender from './aprender';

let barra: Barra;

export function activate(contexto: vscode.ExtensionContext) {
  const saida = vscode.window.createOutputChannel('DataForge');
  contexto.subscriptions.push(saida);

  // A depuração no painel do editor. O adaptador é `dataforge dap`:
  // aqui não há lógica de depuração nenhuma.
  depuracao.registrar(contexto);

  const verificador = new Verificador(contexto);
  const lente = new LenteDeComplexidade();
  const conexoes = new ArvoreDeConexoes(contexto);

  // O servidor de linguagem assume os diagnósticos: ele analisa a cada
  // tecla, e o Verificador só ao salvar. Com os dois ligados, o mesmo
  // erro apareceria duas vezes no painel de problemas — e um deles
  // ficaria desatualizado, que é pior que não estar lá.
  iniciarServidor(contexto, saida).then((subiu) => {
    if (subiu) {
      verificador.desligar();
    } else {
      saida.appendLine('sem servidor: os erros vêm do check ao salvar');
    }
  });

  // ── barra de status ──
  //
  // Antes havia um botão de rodar, e mais nada. Os 60 comandos viviam
  // na paleta — e a paleta só serve a quem já sabe que o comando
  // existe. Agora ela responde cinco perguntas que se fazem o tempo
  // todo: qual interpretador, o arquivo está limpo, a ação do cursor
  // custa quanto, rodar, e os testes passam.
  barra = new Barra(contexto);
  contexto.subscriptions.push(barra);
  barra.atualizar();

  // ── os testes no painel do editor ──
  //
  // O `dataforge test` já era bom; o que faltava era ele aparecer onde
  // se olha, com o triângulo ao lado de cada `trial`.
  testes.registrar(contexto, (passaram, total) =>
    barra.contarTestes(passaram, total));

  // ── comandos ──
  const comandos: [string, (...a: any[]) => any][] = [
    ['dataforge.reiniciarServidor', () => reiniciarServidor(contexto, saida)],

    // Os que faltavam entre a CLI e o editor. Descobrir um comando de
    // CLI exige ler '--help', e ler '--help' exige já suspeitar que ele
    // existe — a paleta é onde se descobre.
    ['dataforge.verTokens', cmd.verTokens],
    ['dataforge.verAst', cmd.verAst],
    ['dataforge.verEstatisticas', cmd.verEstatisticas],
    ['dataforge.perfilar', cmd.perfilar],
    ['dataforge.porQue', cmd.porQue],
    ['dataforge.lint', cmd.lint],
    ['dataforge.corrigir', cmd.corrigir],
    ['dataforge.gerarDoc', cmd.gerarDoc],
    ['dataforge.crucible', cmd.crucible],
    ['dataforge.depurarNoEditor', cmd.depurarNoEditor],
    ['dataforge.depurar', cmd.depurar],
    ['dataforge.avaliar', cmd.avaliar],
    ['dataforge.medirDesempenho', cmd.medirDesempenho],
    ['dataforge.observarArquivo', cmd.observarArquivo],
    ['dataforge.instalarPacotes', cmd.instalarPacotes],
    ['dataforge.acrescentarPacote', cmd.acrescentarPacote],
    ['dataforge.procurarPacote', cmd.procurarPacote],
    ['dataforge.listarPacotes', cmd.listarPacotes],
    ['dataforge.pacotesDesatualizados', cmd.pacotesDesatualizados],
    ['dataforge.arvoreDeDependencias', cmd.arvoreDeDependencias],
    ['dataforge.infoDoProjeto', cmd.infoDoProjeto],
    ['dataforge.limpar', cmd.limpar],
    ['dataforge.listarErros', cmd.listarErros],
    ['dataforge.rodar', () => comEditor((d) => rodarNoTerminal(d))],
    ['dataforge.rodarComTempo', () => comEditor((d) => rodarEMostrarTempo(d))],
    ['dataforge.rodarDepurando', () => comEditor((d) => rodarNoTerminal(d, ['--debug']))],
    ['dataforge.medirRepetido', () => comEditor((d) => medirRepetido(d))],
    ['dataforge.verificar', () => comEditor((d) => verificador.verificar(d))],
    ['dataforge.formatar', () => comEditor(formatar)],
    ['dataforge.testar', () => comEditor((d) => rodarNoTerminal(d, ['crucible']))],
    ['dataforge.complexidade', () => comEditor(mostrarComplexidade)],
    ['dataforge.explicarComplexidade', (a) => explicar(a)],
    ['dataforge.escalaBigO', mostrarEscala],
    ['dataforge.custo', () => anotar(vscode.window.activeTextEditor)],
    ['dataforge.novoProjeto', criarProjeto],
    ['dataforge.repl', abrirRepl],
    ['dataforge.explicarErro', explicarErro],
    ['dataforge.conexoes.adicionar', () => conexoes.adicionar()],
    ['dataforge.conexoes.atualizar', () => conexoes.atualizar()],
    ['dataforge.conexoes.remover', (i: Item) => conexoes.remover(i)],
    ['dataforge.conexoes.testar', (i: Item) => i.conexao && conexoes.testar(i.conexao)],
    ['dataforge.conexoes.inserir', (i: Item) => conexoes.inserirCodigo(i)],
    ['dataforge.cobertura', cmd.cobertura],
    ['dataforge.coberturaMinima', cmd.coberturaMinima],
    ['dataforge.vitrineDev', cmd.vitrineDev],
    ['dataforge.vitrineDoctor', cmd.vitrineDoctor],
    ['dataforge.devops', cmd.devops],
    ['dataforge.devopsDoctor', cmd.devopsDoctor],
    ['dataforge.bigoMedido', medirComplexidade],
    ['dataforge.bigoCurvas', abrirCurvas],
    ['dataforge.menu', abrirMenu],
    ['dataforge.documentacao', () =>
      vscode.env.openExternal(
        vscode.Uri.parse('https://dataforge-lang.vercel.app/docs'))],
    // ── aprender: o passo seguinte ao hover ──
    ['dataforge.abrirDocDoSimbolo', aprender.abrirDocDoSimbolo],
    ['dataforge.palavrasReservadas', aprender.palavrasReservadas],
    ['dataforge.temaDeCores', aprender.temaDeCores],
    ['dataforge.idioma', aprender.idioma],
    // ── converter de outra linguagem ──
    ['dataforge.converterArquivo', converterArquivo],
    ['dataforge.converterSelecao', converterSelecao],
    ['dataforge.converterPasta', converterPasta],
    // ── o servidor ──
    ['dataforge.servidorIniciar', servidorIniciar],
    ['dataforge.servidorParar', () => servidorParar()],
    ['dataforge.servidorReiniciar', servidorReiniciar],
    ['dataforge.servidorAbrir', servidorAbrirNavegador],
  ];
  for (const [nome, fn] of comandos) {
    contexto.subscriptions.push(vscode.commands.registerCommand(nome, fn));
  }

  // ── análise contínua ──
  contexto.subscriptions.push(
    vscode.languages.registerCodeLensProvider(
      { language: 'dataforge' },
      lente,
    ),
    vscode.languages.registerHoverProvider({ language: 'dataforge' }, {
      provideHover: (documento, posicao) => hoverDeComplexidade(documento, posicao),
    }),
    vscode.window.registerTreeDataProvider('dataforgeFerramentas',
                                            new ArvoreDeFerramentas()),
    vscode.window.registerTreeDataProvider('dataforgeConexoes', conexoes),

    vscode.workspace.onDidSaveTextDocument((d) => {
      verificador.agendar(d, 0);
      lente.atualizar();
      if (vscode.window.activeTextEditor?.document === d) {
        void anotar(vscode.window.activeTextEditor);
      }
    }),
    vscode.workspace.onDidChangeTextDocument((e) =>
      verificador.agendar(e.document)),
    vscode.workspace.onDidCloseTextDocument((d) => verificador.limpar(d)),
    vscode.window.onDidChangeActiveTextEditor((e) => {
      barra.atualizar();
      if (e) {
        verificador.agendar(e.document, 0);
        void anotar(e);
      }
    }),
    vscode.workspace.onDidChangeConfiguration((e) => {
      if (e.affectsConfiguration('dataforge.caminho')) esquecerExecutavel();
      lente.atualizar();
      void anotar(vscode.window.activeTextEditor);
    }),
    vscode.window.onDidCloseTerminal(() => fecharTerminal()),
  );

  // Analisa o que já está aberto: sem isto, o primeiro arquivo da
  // sessão fica sem sublinhado até alguém digitar nele.
  if (vscode.window.activeTextEditor) {
    verificador.agendar(vscode.window.activeTextEditor.document, 0);
    void anotar(vscode.window.activeTextEditor);
  }

  prepararIndicador(contexto);

  void avisarSeFaltaOExecutavel();
}

export function deactivate() {
  pararTudo();
  fecharTerminal();
}

// ─────────────────────────────────────────────────────────────

function comEditor(acao: (d: vscode.TextDocument) => any) {
  const editor = vscode.window.activeTextEditor;
  if (!editor || editor.document.languageId !== 'dataforge') {
    vscode.window.showInformationMessage('Abra um arquivo .df primeiro.');
    return;
  }
  return acao(editor.document);
}

async function avisarSeFaltaOExecutavel() {
  // Só avisa se houver um .df aberto: quem instalou a extensão e ainda
  // não usou a linguagem não precisa de um popup.
  if (vscode.window.activeTextEditor?.document.languageId !== 'dataforge') return;
  await exigirExecutavel();
}

async function formatar(documento: vscode.TextDocument) {
  const exe = await exigirExecutavel();
  if (!exe) return;
  await documento.save();
  await rodar(exe, ['fmt', documento.uri.fsPath], 20000, raizDe(documento));
  vscode.window.setStatusBarMessage('DataForge: formatado', 3000);
}

async function abrirRepl() {
  const exe = await exigirExecutavel();
  if (!exe) return;
  const t = vscode.window.createTerminal({
    name: 'DataForge REPL',
    iconPath: new vscode.ThemeIcon('terminal'),
  });
  t.show();
  t.sendText(`${exe} repl`, true);
}

async function mostrarComplexidade(documento: vscode.TextDocument) {
  const exe = await exigirExecutavel();
  if (!exe) return;
  await documento.save();

  const saida = obterCanal();
  saida.show(true);
  const { saida: texto } = await rodar(
    exe,
    ['big-o', documento.uri.fsPath, '-v', '--no-color'],
    30000,
    raizDe(documento),
  );
  saida.appendLine('');
  saida.appendLine(texto.trimEnd());
}

async function mostrarEscala() {
  const exe = await exigirExecutavel();
  if (!exe) return;
  const saida = obterCanal();
  saida.show(true);
  const { saida: texto } = await rodar(exe, ['big-o', '--escala', '--no-color']);
  saida.appendLine(texto.trimEnd());
}

/** O código do erro sob o cursor, explicado. */
async function explicarErro() {
  const editor = vscode.window.activeTextEditor;
  if (!editor) return;

  const selecionado = editor.document.getText(editor.selection).trim();
  const codigo =
    /^DF\d{4}$/i.test(selecionado)
      ? selecionado
      : await vscode.window.showInputBox({
          title: 'Código do erro',
          placeHolder: 'DF0601, ou o nome da classe (KeyError)',
        });
  if (!codigo) return;

  const exe = await exigirExecutavel();
  if (!exe) return;

  const saida = obterCanal();
  saida.show(true);
  const { saida: texto } = await rodar(exe, ['explain', codigo, '--no-color']);
  saida.appendLine(texto.trimEnd());
}

/** O hover mostra o porquê da complexidade da ação sob o cursor. */
function hoverDeComplexidade(
  documento: vscode.TextDocument,
  posicao: vscode.Position,
): vscode.Hover | undefined {
  const acoes = acoesDe(documento.uri);
  const acao = acoes.find((a) => a.linha - 1 === posicao.line);
  if (!acao) return undefined;

  const md = new vscode.MarkdownString();
  md.appendMarkdown(`**${acao.tempo.notacao}** de tempo — ${acao.tempo.nome}\n\n`);
  md.appendMarkdown(`**${acao.espaco.notacao}** de espaço\n\n`);
  if (acao.tempo.motivos.length) {
    acao.tempo.motivos.forEach((m) => md.appendMarkdown(`- ${m}\n`));
  }
  for (const aviso of acao.avisos) {
    md.appendMarkdown(`\n⚠ **${aviso.texto}**\n\n${aviso.sugestao}\n`);
  }
  md.isTrusted = true;
  return new vscode.Hover(md);
}
