"""
DataForge AST Node Definitions
Abstract Syntax Tree nodes produced by the parser.
"""

from dataclasses import dataclass, field
from typing import Any


# ═══════════════════════════════════════════════════════════
#  BASE
# ═══════════════════════════════════════════════════════════

@dataclass
class ASTNode:
    """Base class for all AST nodes."""
    line: int = 0
    column: int = 0


# ═══════════════════════════════════════════════════════════
#  PROGRAM
# ═══════════════════════════════════════════════════════════

@dataclass
class Program(ASTNode):
    """Root node: list of statements."""
    body: list = field(default_factory=list)


# ═══════════════════════════════════════════════════════════
#  LITERALS
# ═══════════════════════════════════════════════════════════

@dataclass
class IntegerLiteral(ASTNode):
    value: int = 0

@dataclass
class FloatLiteral(ASTNode):
    value: float = 0.0

@dataclass
class DecimalLiteral(ASTNode):
    """'19.99d' — o valor ja e um Decimal, construido do texto.

    Ele tem no proprio porque um Float com um Decimal dentro seria um no
    que mente, e porque o formatador, o 'tokens' e a coloracao do editor
    leem o tipo do token para desenhar.
    """
    value: object = None

@dataclass
class StringLiteral(ASTNode):
    value: str = ""

@dataclass
class BooleanLiteral(ASTNode):
    value: bool = False

@dataclass
class VoidLiteral(ASTNode):
    pass

@dataclass
class ListLiteral(ASTNode):
    elements: list = field(default_factory=list)

@dataclass
class TupleLiteral(ASTNode):
    """(1, "a") — sequência de tamanho fixo e imutável.

    '(1)' NÃO é tupla: é agrupamento, e essa é a única ambiguidade da
    forma. A tupla de um item se escreve '(1,)', como em Python.
    """
    elements: list = field(default_factory=list)


@dataclass
class DictLiteral(ASTNode):
    pairs: list = field(default_factory=list)  # list of (key, value) tuples


# ═══════════════════════════════════════════════════════════
#  EXPRESSIONS
# ═══════════════════════════════════════════════════════════

@dataclass
class Identifier(ASTNode):
    name: str = ""

@dataclass
class BinaryOp(ASTNode):
    left: Any = None
    op: str = ""
    right: Any = None

@dataclass
class UnaryOp(ASTNode):
    op: str = ""
    operand: Any = None

@dataclass
class ComparisonOp(ASTNode):
    left: Any = None
    op: str = ""  # is, isnt, bigger, smaller, bigger_eq, smaller_eq
    right: Any = None

@dataclass
class LogicalOp(ASTNode):
    left: Any = None
    op: str = ""  # and, or
    right: Any = None

@dataclass
class NotOp(ASTNode):
    operand: Any = None

@dataclass
class ValorPronto(ASTNode):
    """Embrulha um valor ja calculado para reaproveita-lo numa arvore.

    Serve a quem precisa montar um no de expressao a partir de algo que
    ja foi avaliado — a atribuicao composta, que nao pode avaliar o alvo
    duas vezes.
    """
    value: Any = None


@dataclass
class Assignment(ASTNode):
    """alvo := valor   |   alvo += valor (com compound_op preenchido)

    Numa atribuicao composta, 'value' e so o lado direito — nao o
    BinaryOp inteiro. O interpretador avalia o alvo uma vez, le, aplica e
    escreve. Guardar o BinaryOp aqui faria o alvo ser avaliado duas
    vezes, e 'v[sortear()] += 1' consumiria dois sorteios.
    """
    target: Any = None
    value: Any = None
    declared_type: str = ""
    compound_op: str = ""

@dataclass
class SteadyDeclaration(ASTNode):
    """Immutable constant: steady NAME := value"""
    name: str = ""
    value: Any = None

@dataclass
class MemberAccess(ASTNode):
    """object.member"""
    object: Any = None
    member: str = ""

@dataclass
class IndexAccess(ASTNode):
    """object[index]"""
    object: Any = None
    index: Any = None

@dataclass
class SliceAccess(ASTNode):
    """obj[start:stop:step]"""
    object: Any = None
    start: Any = None
    stop: Any = None
    step: Any = None


@dataclass
class LambdaExpression(ASTNode):
    """lambda a, b: expression"""
    params: list = field(default_factory=list)
    defaults: dict = field(default_factory=dict)
    body: Any = None
    param_types: dict = field(default_factory=dict)


@dataclass
class FunctionCall(ASTNode):
    callee: Any = None
    args: list = field(default_factory=list)
    kwargs: dict = field(default_factory=dict)

@dataclass
class MethodCall(ASTNode):
    object: Any = None
    method: str = ""
    args: list = field(default_factory=list)
    kwargs: dict = field(default_factory=dict)

@dataclass
class SpawnExpression(ASTNode):
    """spawn ClassName(args)"""
    class_name: Any = None
    args: list = field(default_factory=list)
    kwargs: dict = field(default_factory=dict)

@dataclass
class TypeofExpression(ASTNode):
    """typeof expr"""
    operand: Any = None

@dataclass
class CastExpression(ASTNode):
    """cast expr as Type"""
    operand: Any = None
    target_type: str = ""

@dataclass
class PipelineExpression(ASTNode):
    """data >> sift/morph/distill ..."""
    source: Any = None
    operations: list = field(default_factory=list)

@dataclass
class SiftOperation(ASTNode):
    """sift var: condition  OR  sift func_name"""
    param: str = ""
    condition: Any = None
    func_ref: str = ""  # Named function reference

@dataclass
class QuadroOperation(ASTNode):
    """Um verbo de quadro num pipeline: `>> onde …`, `>> agrupar …`.

    Um nó só para os seis verbos, com `verbo` dizendo qual — eles
    compartilham a forma (nomes de coluna, ou uma expressão) e um nó por
    verbo daria seis classes quase iguais.

    As palavras são CONTEXTUAIS, como as do Kiln: elas só valem logo
    depois de um `>>`, e continuam livres como nome de variável em todo o
    resto da linguagem. `agrupar` e `ordenar` são nomes bons demais para
    tirar de quem escreve.
    """
    verbo: str = ""              # onde · pegar · sem · agrupar · resumir · ordenar
    colunas: list = field(default_factory=list)
    expressao: Any = None        # 'onde' e 'resumir'
    decrescente: bool = False    # só 'ordenar'


@dataclass
class MorphOperation(ASTNode):
    """morph var: expression  OR  morph func_name"""
    param: str = ""
    expression: Any = None
    func_ref: str = ""  # Named function reference

@dataclass
class DistillOperation(ASTNode):
    """distill acc, var: expression  OR  distill func_name initial"""
    acc_param: str = ""
    val_param: str = ""
    expression: Any = None
    initial: Any = None
    func_ref: str = ""  # Named function reference

@dataclass
class AwaitExpression(ASTNode):
    expression: Any = None

# ═══════════════════════════════════════════════════════════
#  STATEMENTS
# ═══════════════════════════════════════════════════════════

@dataclass
class OutStatement(ASTNode):
    """out expression"""
    expressions: list = field(default_factory=list)

@dataclass
class InExpression(ASTNode):
    """in "prompt" """
    prompt: Any = None

@dataclass
class YieldStatement(ASTNode):
    """yield expression"""
    value: Any = None

@dataclass
class HaltStatement(ASTNode):
    """halt (break)"""
    pass

@dataclass
class SkipStatement(ASTNode):
    """skip (continue)"""
    pass

@dataclass
class TriggerStatement(ASTNode):
    """trigger expression"""
    value: Any = None

@dataclass
class DeleteStatement(ASTNode):
    """delete target"""
    target: Any = None

@dataclass
class AssertStatement(ASTNode):
    """assert expression"""
    condition: Any = None
    message: Any = None

@dataclass
class WaitStatement(ASTNode):
    """wait(ms)"""
    duration: Any = None

@dataclass
class InspectStatement(ASTNode):
    """inspect expression"""
    expression: Any = None


# ═══════════════════════════════════════════════════════════
#  CONTROL FLOW
# ═══════════════════════════════════════════════════════════

@dataclass
class GivenBlock(ASTNode):
    """given ... : / orif ... : / otherwise:"""
    condition: Any = None
    body: list = field(default_factory=list)
    orif_blocks: list = field(default_factory=list)  # list of (condition, body)
    otherwise_body: list = field(default_factory=list)

@dataclass
class MatchBlock(ASTNode):
    """match expression: / point value: / default:"""
    expression: Any = None
    points: list = field(default_factory=list)    # list of (value, body)
    default_body: list = field(default_factory=list)


# ═══════════════════════════════════════════════════════════
#  LOOPS
# ═══════════════════════════════════════════════════════════

@dataclass
class CycleFromTo(ASTNode):
    """cycle var from start to end [step s]:"""
    var: str = ""
    start: Any = None
    end: Any = None
    step: Any = None
    body: list = field(default_factory=list)

@dataclass
class CycleIn(ASTNode):
    """cycle x in colecao:  |  cycle i, item in enumerate(colecao):

    'vars' guarda os nomes quando o laco desestrutura cada item. Fica
    ao lado de 'var' em vez de substitui-lo porque o caso de um nome
    so e a esmagadora maioria, e um par ('nome', None) em toda parte
    custaria mais que o campo extra.
    """
    var: str = ""
    vars: list = field(default_factory=list)
    collection: Any = None
    body: list = field(default_factory=list)

@dataclass
class PersistBlock(ASTNode):
    """persist condition:"""
    condition: Any = None
    body: list = field(default_factory=list)

@dataclass
class PerformBlock(ASTNode):
    """perform: ... persist condition"""
    body: list = field(default_factory=list)
    condition: Any = None


# ═══════════════════════════════════════════════════════════
#  FUNCTIONS & CLASSES
# ═══════════════════════════════════════════════════════════

@dataclass
class ActionDeclaration(ASTNode):
    """action name(params):"""
    name: str = ""
    params: list = field(default_factory=list)
    defaults: dict = field(default_factory=dict)
    body: list = field(default_factory=list)
    is_async: bool = False
    decorators: list = field(default_factory=list)
    type_params: list = field(default_factory=list)
    type_bounds: dict = field(default_factory=dict)  # 'T' -> limite de <T extends X>
    param_types: dict = field(default_factory=dict)
    return_type: str = ""
    is_generator: bool = False
    visibility: str = "public"   # public | private | protected | internal
    is_static: bool = False
    is_abstract: bool = False
    is_final: bool = False
    # ── OOP 1.2 ──
    is_override: bool = False    # 'override action f()' — tem de sobrescrever algo
    is_overload: bool = False    # 'overload action f(x: Integer)' — uma variante
    is_exclusive: bool = False   # 'exclusive action f()' — uma thread por vez
    # 'promises cond' do topo do corpo, tirados dali pelo parser: rodam
    # na SAIDA da acao, com 'outcome' ligado ao valor devolvido.
    postconditions: list = field(default_factory=list)

@dataclass
class BlueprintDeclaration(ASTNode):
    """blueprint Name [(params)] [extends Parent] [with Trait]:"""
    name: str = ""
    parents: list = field(default_factory=list)
    body: list = field(default_factory=list)
    traits: list = field(default_factory=list)
    constructor_params: list = field(default_factory=list)
    # (nome, tipo, padrao, visibilidade) — campos declarados no corpo
    fields_decl: list = field(default_factory=list)
    is_abstract: bool = False
    decorators: list = field(default_factory=list)
    # (nome_do_campo, [decoradores]) — decoradores em campos declarados
    field_decorators: dict = field(default_factory=dict)
    # <T>, <K, V> — nomes de tipo validos dentro desta declaracao
    type_params: list = field(default_factory=list)
    type_bounds: dict = field(default_factory=dict)  # 'T' -> limite de <T extends X>
    # ── OOP 1.2 ──
    is_final: bool = False       # 'final blueprint' — ninguem herda
    is_sealed: bool = False      # 'sealed blueprint' — so herda quem esta no mesmo arquivo
    is_meta: bool = False        # 'meta blueprint' — governa a criacao de outros
    metaclass: str = ""          # 'using Meta' no cabecalho
    constructor_types: dict = field(default_factory=dict)     # 'x' -> 'Integer'
    constructor_defaults: dict = field(default_factory=dict)  # 'x' -> expressao
    # campo -> {'readonly', 'internal', …} — os modificadores de cada campo
    field_modifiers: dict = field(default_factory=dict)


@dataclass
class ContractDeclaration(ASTNode):
    """contract Nome<T> [extends A, B]: assinaturas

    O que um blueprint PROMETE, sem nada do COMO. Diferente do trait,
    que pode trazer implementacao padrao, um contrato so declara — e e
    isso que o deixa ser segregado em pedacos pequenos sem arrastar
    codigo junto.
    """
    name: str = ""
    parents: list = field(default_factory=list)       # outros contratos
    members: list = field(default_factory=list)       # ActionDeclaration / PropertyDeclaration sem corpo
    type_params: list = field(default_factory=list)
    type_bounds: dict = field(default_factory=dict)
    decorators: list = field(default_factory=list)


@dataclass
class AugmentDeclaration(ASTNode):
    """augment Nome: membros — acrescenta a um blueprint que ja existe."""
    name: str = ""
    body: list = field(default_factory=list)
    fields_decl: list = field(default_factory=list)
    field_modifiers: dict = field(default_factory=dict)


@dataclass
class InvariantStatement(ASTNode):
    """invariant cond [, "mensagem"] — vale depois de toda operacao publica."""
    condition: Any = None
    message: Any = None


@dataclass
class ExpectsStatement(ASTNode):
    """expects cond [, "mensagem"] — pre-condicao: quem chamou errou."""
    condition: Any = None
    message: Any = None


@dataclass
class PromisesStatement(ASTNode):
    """promises cond [, "mensagem"] — pos-condicao: a acao errou."""
    condition: Any = None
    message: Any = None


@dataclass
class BeforeExpression(ASTNode):
    """before(expr) — o valor de expr na ENTRADA da acao, dentro de 'promises'."""
    expression: Any = None


@dataclass
class PropertyDeclaration(ASTNode):
    """get nome(): ...  |  set nome(valor): ...

    Uma propriedade e lida e escrita como campo, mas roda codigo.
    """
    name: str = ""
    kind: str = "get"            # 'get' ou 'set'
    param: str = ""              # so no set: o nome do valor recebido
    body: list = field(default_factory=list)
    visibility: str = "public"
    return_type: str = ""
    is_lazy: bool = False        # 'lazy get total()' — calcula uma vez por objeto
    is_override: bool = False
    is_abstract: bool = False    # assinatura sem corpo, num contrato


@dataclass
class OperatorDeclaration(ASTNode):
    """operator + (outro): ... — sobrecarga de operador."""
    symbol: str = ""             # '+', '-', '*', '/', '%', '**', '==', '<', …
    param: str = ""
    body: list = field(default_factory=list)
    line: int = 0
    column: int = 0

@dataclass
class TraitDeclaration(ASTNode):
    """trait Name [<T>] [extends Outro]:"""
    name: str = ""
    methods: list = field(default_factory=list)
    parents: list = field(default_factory=list)      # 'trait B extends A'
    type_params: list = field(default_factory=list)
    type_bounds: dict = field(default_factory=dict)

@dataclass
class ComptimeBlock(ASTNode):
    """comptime <instrução>   |   comptime: <bloco>

    O corpo roda UMA vez, na carga, numa caixa sem E/S nem módulos — e o
    que ele define vira constante para o resto do programa.
    """
    body: list = field(default_factory=list)


@dataclass
class TypeDeclaration(ASTNode):
    """type Nome := Base | Outro where regra — e 'opaque type' também.

    Uma declaração só para as cinco formas: o que muda é `especie`
    (alias, uniao, intersecao), a regra opcional e o `opaco`.
    """
    name: str = ""
    especie: str = "alias"
    partes: list = field(default_factory=list)   # os nomes do lado direito
    type_params: list = field(default_factory=list)   # 'type Par<T> := …'
    regra: Any = None                            # a expressão do 'where'
    regra_texto: str = ""                        # como ela foi escrita
    opaco: bool = False


@dataclass
class StaticDeclaration(ASTNode):
    """static name := value"""
    name: str = ""
    value: Any = None
    declared_type: str = ""
    is_steady: bool = False      # 'static steady MAX := 3' — constante de classe


# ═══════════════════════════════════════════════════════════
#  ERROR HANDLING
# ═══════════════════════════════════════════════════════════

@dataclass
class HandleClause(ASTNode):
    """Uma clausula 'handle' de um 'monitor'.

    'error_type' vazio captura qualquer erro; 'error_name' e sempre um
    nome, porque o erro precisa poder ser lido mesmo quando quem
    escreveu nao pediu um ('handle KeyError:' liga 'error').
    """
    error_type: str = ""
    error_name: str = "error"
    body: list = field(default_factory=list)


@dataclass
class MonitorBlock(ASTNode):
    """monitor: / handle: … / ensure:

    'handles' e uma LISTA: um 'monitor' aceita uma clausula por tipo de
    erro, e vence a primeira que casar. Com uma so, quem quisesse tratar
    dois erros de formas diferentes tinha de capturar 'Error' e
    despachar na mao — o que o handle tipado existe para evitar.
    """
    body: list = field(default_factory=list)
    handles: list = field(default_factory=list)
    ensure_body: list = field(default_factory=list)


@dataclass
class GuardStatement(ASTNode):
    """guard condition else: body"""
    condition: Any = None
    message: Any = None
    else_body: list = field(default_factory=list)


@dataclass
class RetryBlock(ASTNode):
    """retry count: body"""
    count: Any = None
    body: list = field(default_factory=list)
    handle_name: str = "error"
    handle_body: list = field(default_factory=list)


@dataclass
class ValidateStatement(ASTNode):
    """validate value otherwise: else_body"""
    value: Any = None
    predicate: Any = None
    message: Any = None
    else_body: list = field(default_factory=list)


@dataclass
class PropagateStatement(ASTNode):
    """propagate (re-raise current error)"""
    value: Any = None


@dataclass
class DeferStatement(ASTNode):
    """defer: body (runs at end of scope)"""
    body: list = field(default_factory=list)


@dataclass
class ObserveBlock(ASTNode):
    """observe source: body"""
    source: Any = None
    var: str = ""
    body: list = field(default_factory=list)


@dataclass
class StreamExpression(ASTNode):
    """stream data"""
    source: Any = None


@dataclass
class ParallelBlock(ASTNode):
    """parallel: blocks"""
    blocks: list = field(default_factory=list)


# ═══════════════════════════════════════════════════════════
#  MODULES
# ═══════════════════════════════════════════════════════════

@dataclass
class AdoptStatement(ASTNode):
    """adopt Modulo [as Alias] | adopt {a, b as c} from Modulo"""
    module: str = ""
    alias: str = ""
    selection: list = None      # [(nome, apelido)] quando o import é seletivo

@dataclass
class RelayStatement(ASTNode):
    """relay nome, outro   |   relay from ./modulo

    Com 'origem' preenchida, e re-exportacao: tudo o que aquele modulo
    exporta passa a sair tambem por este. E o que permite montar uma
    fachada — um index.df que reune varios modulos internos numa API so.
    """
    names: list = field(default_factory=list)
    origem: str = ""


# ═══════════════════════════════════════════════════════════
#  ASYNC & CONCURRENCY
# ═══════════════════════════════════════════════════════════

@dataclass
class ThreadBlock(ASTNode):
    """thread: body"""
    body: list = field(default_factory=list)

@dataclass
class ChannelDeclaration(ASTNode):
    """channel name"""
    name: str = ""

@dataclass
class PulseStatement(ASTNode):
    """pulse event_name, data"""
    event: Any = None
    data: Any = None


# ═══════════════════════════════════════════════════════════
#  DECORATORS
# ═══════════════════════════════════════════════════════════

@dataclass
class MarkDecorator(ASTNode):
    """@Nome  ou  @Nome(argumentos)

    Aplica-se a acao, blueprint, record, metodo e campo. O 'mark' antes
    do '@' continua aceito, mas e opcional — '@Nome' sozinho e a forma
    normal, e a que a documentacao ensina.
    """
    name: str = ""
    args: list = field(default_factory=list)
    kwargs: dict = field(default_factory=dict)


# ═══════════════════════════════════════════════════════════
#  DATA SCIENCE
# ═══════════════════════════════════════════════════════════

@dataclass
class FrameExpression(ASTNode):
    """frame [[...], [...]]"""
    data: Any = None
    columns: list = field(default_factory=list)

@dataclass
class TrainExpression(ASTNode):
    """train model using data"""
    model: Any = None
    data: Any = None

@dataclass
class PredictExpression(ASTNode):
    """predict model using data"""
    model: Any = None
    data: Any = None


# ═══════════════════════════════════════════════════════════
#  SHADOW
# ═══════════════════════════════════════════════════════════

@dataclass
class ShadowDeclaration(ASTNode):
    """shadow name := value"""
    name: str = ""
    value: Any = None


# ═══════════════════════════════════════════════════════════
#  DataForge 4.0 — EXPRESSÕES
# ═══════════════════════════════════════════════════════════

@dataclass
class InterpolatedString(ASTNode):
    """$"texto {expr} texto" — partes já resolvidas em nós."""
    parts: list = field(default_factory=list)   # [('text', str) | ('expr', ASTNode)]


@dataclass
class TernaryExpression(ASTNode):
    """valor_se_verdadeiro given condicao otherwise valor_se_falso"""
    then_value: Any = None
    condition: Any = None
    else_value: Any = None


@dataclass
class MembershipOp(ASTNode):
    """x in colecao  /  x not in colecao"""
    element: Any = None
    container: Any = None
    negated: bool = False


@dataclass
class CoalesceOp(ASTNode):
    """a ?? b — devolve b quando a for void"""
    left: Any = None
    right: Any = None


@dataclass
class SafeMemberAccess(ASTNode):
    """obj?.membro — void quando obj for void"""
    object: Any = None
    member: str = ""


@dataclass
class SafeMethodCall(ASTNode):
    """obj?.metodo(args)"""
    object: Any = None
    method: str = ""
    args: list = field(default_factory=list)
    kwargs: dict = field(default_factory=dict)


@dataclass
class SpreadElement(ASTNode):
    """...expr dentro de lista, vault ou chamada"""
    value: Any = None


@dataclass
class ComprehensionClause(ASTNode):
    """cycle <var> in <fonte> [given <cond>]"""
    var: str = ""
    targets: list = field(default_factory=list)   # desestruturação no cycle
    source: Any = None
    condition: Any = None


@dataclass
class ListComprehension(ASTNode):
    """[expr cycle x in fonte given cond]"""
    expression: Any = None
    clauses: list = field(default_factory=list)


@dataclass
class VaultComprehension(ASTNode):
    """{k: v cycle x in fonte given cond}"""
    key: Any = None
    value: Any = None
    clauses: list = field(default_factory=list)


# ═══════════════════════════════════════════════════════════
#  DataForge 4.0 — DECLARAÇÕES
# ═══════════════════════════════════════════════════════════

@dataclass
class RecordDeclaration(ASTNode):
    """record Nome: campo: Tipo [:= padrao]"""
    name: str = ""
    fields: list = field(default_factory=list)     # [(nome, tipo, default|None)]
    methods: dict = field(default_factory=dict)    # nome -> ActionDeclaration
    decorators: list = field(default_factory=list)
    field_decorators: dict = field(default_factory=dict)
    type_params: list = field(default_factory=list)
    type_bounds: dict = field(default_factory=dict)  # 'T' -> limite de <T extends X>


@dataclass
class EnumDeclaration(ASTNode):
    """enum Nome: MEMBRO [:= valor]"""
    name: str = ""
    members: list = field(default_factory=list)    # [(nome, valor_expr|None)]
    methods: dict = field(default_factory=dict)
    type_params: list = field(default_factory=list)
    type_bounds: dict = field(default_factory=dict)


@dataclass
class DestructuringAssignment(ASTNode):
    """a, b := expr   |   a, ...resto := expr   |   {nome, idade} := registro"""
    targets: list = field(default_factory=list)    # [(nome, is_rest)]
    value: Any = None
    is_mapping: bool = False                       # forma {a, b} := vault/record
    declared_types: dict = field(default_factory=dict)


@dataclass
class WithExpression(ASTNode):
    """registro with {"campo": valor} — cópia alterada"""
    source: Any = None
    changes: Any = None


# ═══════════════════════════════════════════════════════════
#  DataForge 4.0 — PATTERN MATCHING
# ═══════════════════════════════════════════════════════════

@dataclass
class Pattern(ASTNode):
    """Base dos padrões de 'point'."""
    binding: str = ""        # 'padrao as nome'


@dataclass
class WildcardPattern(Pattern):
    """_ — casa com qualquer coisa"""


@dataclass
class LiteralPattern(Pattern):
    """1, "a", yes, void — casa por igualdade"""
    value: Any = None


@dataclass
class CapturePattern(Pattern):
    """nome — casa com qualquer coisa e liga ao nome"""
    name: str = ""


@dataclass
class TypePattern(Pattern):
    """Integer, Usuario — casa pelo tipo"""
    type_name: str = ""
    sub_patterns: list = field(default_factory=list)   # Usuario(a, b)
    field_patterns: dict = field(default_factory=dict) # Usuario(nome := p)


@dataclass
class SequencePattern(Pattern):
    """[a, b, ...resto]"""
    elements: list = field(default_factory=list)
    rest_index: int = -1
    rest_name: str = ""


@dataclass
class MappingPattern(Pattern):
    """{"chave": padrao, ...}"""
    pairs: list = field(default_factory=list)   # [(chave_expr, padrao)]
    rest_name: str = ""


@dataclass
class ValuePattern(Pattern):
    """Status.Ativo — casa por igualdade com um valor nomeado"""
    expression: Any = None


@dataclass
class OrPattern(Pattern):
    """p1 or p2"""
    options: list = field(default_factory=list)


@dataclass
class MatchCase(ASTNode):
    """point <padrao> [when <guarda>]: corpo"""
    pattern: Any = None
    guard: Any = None
    body: list = field(default_factory=list)


# ═══════════════════════════════════════════════════════════
#  DataForge 4.0 — GENERATORS
# ═══════════════════════════════════════════════════════════

@dataclass
class EmitStatement(ASTNode):
    """emit valor — produz num 'stream action'; imprime fora dele (legado)."""
    expressions: list = field(default_factory=list)


@dataclass
class _Wrapped(ASTNode):
    """Nó interno: transporta um valor já avaliado para reaproveitar um eval_*."""
    value: Any = None


# ═══════════════════════════════════════════════════════════
#  DataForge 4.2 — KILN (framework web)
# ═══════════════════════════════════════════════════════════

@dataclass
class ServerBlock(ASTNode):
    """server <nome> [on <porta>] [at <host>]: corpo

    Liga <nome> a uma aplicacao Kiln. Nao sobe nada — quem acende o
    forno e o 'ignite'.
    """
    name: str = ""
    port: Any = None
    host: Any = None
    body: list = field(default_factory=list)


@dataclass
class RouteBlock(ASTNode):
    """route <VERBO> "<caminho>": corpo

    Dentro do corpo existem 'req' e os atalhos 'params', 'query',
    'body' e 'headers'.
    """
    method: str = "GET"
    path: Any = None
    body: list = field(default_factory=list)


@dataclass
class RespondStatement(ASTNode):
    """respond [status] [json|html|text|file] <expr>"""
    value: Any = None
    kind: str = ""            # "", "json", "html", "text", "file"
    status: Any = None


@dataclass
class RenderStatement(ASTNode):
    """render "<template>" [with <vault>] [status <n>]"""
    template: Any = None
    data: Any = None
    status: Any = None


@dataclass
class RedirectStatement(ASTNode):
    """redirect "<destino>" [status <n>]"""
    target: Any = None
    status: Any = None


@dataclass
class MiddlewareStatement(ASTNode):
    """middleware <expr> — antes da rota;  after <expr> — depois dela.

    Sao o mesmo no com um sinalizador, e nao dois: o que muda e a fila
    em que a funcao entra, nao a forma de ler nem de checar. Um no
    separado obrigaria a duplicar o metodo do typechecker para nada.
    """
    value: Any = None
    depois: bool = False


@dataclass
class MountStatement(ASTNode):
    """mount <expr> at "<prefixo>" — junta outro server sob um prefixo."""
    value: Any = None
    prefix: Any = None


@dataclass
class AssetsStatement(ASTNode):
    """assets "<prefixo>" from "<pasta>" — serve arquivos do disco."""
    prefix: Any = None
    folder: Any = None


@dataclass
class ViewsStatement(ASTNode):
    """views "<pasta>" — onde ficam os templates."""
    folder: Any = None


@dataclass
class IgniteStatement(ASTNode):
    """ignite <server> [on <porta>] — acende o forno (bloqueia)."""
    target: Any = None
    port: Any = None
    host: Any = None


# ═════════════════════════════════════════════════════════════
#  Crucible — o framework de testes
# ═════════════════════════════════════════════════════════════

@dataclass
class CrucibleBlock(ASTNode):
    """crucible "<nome>" [tagged "a", "b"]: corpo

    Abre uma suite. Suites aninham: um 'crucible' dentro de outro cria
    um grupo filho, que herda os ganchos e as fixtures do pai.
    """
    name: Any = None
    tags: list = field(default_factory=list)
    pending: Any = None
    body: list = field(default_factory=list)


@dataclass
class TrialBlock(ASTNode):
    """trial "<nome>" [modificadores]: corpo

    Modificadores:
        tagged "lento", "rede"      marca, para filtrar depois
        pending "motivo"            nao roda, e o relatorio diz por que
        only                        so os focados rodam
        repeat <n>                  roda n vezes; instabilidade aparece
        within <ms>                 falha se passar do prazo
        over <tabela>               um caso por linha, com 'caso' ligado
    """
    name: Any = None
    tags: list = field(default_factory=list)
    pending: Any = None
    focused: bool = False
    repeat: Any = None
    within: Any = None
    over: Any = None
    body: list = field(default_factory=list)


@dataclass
class ExpectStatement(ASTNode):
    """expect <expr> [<matcher> <argumentos>]

    Duas formas, e as duas viram a mesma cadeia:

        expect(total).to_be(10)     encadeada, como na biblioteca
        expect total is 10          a forma curta, so para os comuns
    """
    value: Any = None
    matcher: str = ""
    args: list = field(default_factory=list)
    negated: bool = False


@dataclass
class FixtureBlock(ASTNode):
    """fixture <nome>(): corpo

    O corpo prepara, entrega com 'provide', e o que vem depois do
    'provide' limpa. A limpeza roda mesmo quando o trial falha.
    """
    name: str = ""
    params: list = field(default_factory=list)
    scope: str = "trial"          # "trial" | "suite" | "arquivo"
    body: list = field(default_factory=list)


@dataclass
class ProvideStatement(ASTNode):
    """provide <valor> — entrega o valor preparado ao trial."""
    value: Any = None


@dataclass
class HookBlock(ASTNode):
    """setup: / teardown: — o que roda em volta de cada trial.

    Com 'all' ('setup all:'), roda uma vez para a suite inteira.
    """
    kind: str = "setup"           # "setup" | "teardown"
    every: bool = True            # False = uma vez por suite
    body: list = field(default_factory=list)


@dataclass
class BenchBlock(ASTNode):
    """bench "<nome>" [times <n>]: corpo

    Mede em vez de cobrar. Sai no relatorio com media, mediana e p95 —
    a media sozinha esconde a pausa do coletor de lixo.
    """
    name: Any = None
    times: Any = None
    body: list = field(default_factory=list)


@dataclass
class WithBlock(ASTNode):
    """with <recurso> [as <nome>]: corpo

    Abre um recurso, roda o corpo, e o fecha — mesmo se o corpo falhar.

    'defer' já garante limpeza, mas na saída do ESCOPO. Um recurso
    aberto no meio de uma ação longa fica aberto até o fim dela; com
    'with', ele fecha no fim do bloco, que é onde deixou de ser usado.
    """
    resource: Any = None
    name: str = ""
    body: list = field(default_factory=list)


@dataclass
class SlotsDeclaration(ASTNode):
    """slots ["a", "b"] — os únicos campos que a instância pode ter.

    Duas coisas de uma vez: pega o campo digitado errado na hora da
    atribuição (em vez de deixá-lo virar um campo fantasma que nada
    lê), e faz a instância guardar os valores numa lista em vez de num
    dicionário — 64% menos memória por objeto.
    """
    names: list = field(default_factory=list)
