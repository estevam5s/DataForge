"""
Arcane.Concurrent — threads, processos e sincronizacao de verdade.

    adopt Arcane.Concurrent as P

    // um trabalhador por item, com teto
    resultados := P.map(baixar, urls, trabalhadores := 8)

    // travas de verdade
    trava := P.mutex()
    P.com_trava(trava, lambda => contador.somar())

    // processos, para trabalho de CPU
    somas := P.map_processos(calcular_pesado, blocos)

─── Thread ou processo? ────────────────────────────────────

A pergunta e sempre a mesma: o trabalho ESPERA ou CALCULA?

    espera (rede, disco, banco)  ->  thread
    calcula (numeros, imagem)    ->  processo

O motivo e o GIL: duas threads Python nunca executam bytecode ao mesmo
tempo. Para trabalho que espera, isso nao importa — a thread solta o
GIL enquanto espera, e dez downloads acontecem juntos. Para trabalho
que calcula, oito threads levam o mesmo tempo que uma; so processos
usam os oito nucleos.

'P.map' usa threads. 'P.map_processos' usa processos, e paga o custo
de serializar os dados — vale a partir de alguns milissegundos de
trabalho por item.

─── O que o 'thread' da linguagem nao resolvia ─────────────

A palavra 'thread' ja existia e dispara uma linha de execucao. O que
faltava era o resto: esperar por ela, coletar o que ela devolveu,
limitar quantas rodam juntas, e coordenar o acesso ao que elas
compartilham. Sem isso, duas threads escrevendo no mesmo vault perdem
atualizacoes — e o bug so aparece sob carga.
"""

import concurrent.futures as futuros
import concurrent.futures.process  # noqa: F401
import os
import queue
import sys
import threading
import time

from ..errors import (ConcurrencyError, DeadlockError, RuntimeError_,
                      TimeoutError_, ThreadError, TypeError_)
from ..travessia import _ErroDoFilho
from ..builtins import _df_type as _nome_do_tipo


#: Quantos trabalhadores por padrao.
#:
#: Para espera, mais que nucleos compensa: a maior parte do tempo cada
#: um esta parado. Para calculo, mais que nucleos so acrescenta troca
#: de contexto.
PADRAO_THREADS = min(32, (os.cpu_count() or 4) * 4)
#: O processo filho nasce por SPAWN, e nao por fork — nos tres sistemas.
#:
#: No Linux o padrao e 'fork', e ele copia a memoria do pai: uma conexao
#: de banco, um arquivo aberto ou um soquete chegam ao filho "funcionando"
#: sem passar por 'travessia.py'. Tres problemas, e o terceiro e o que
#: decide:
#:
#:   1. o modelo da travessia e copiar a DECLARACAO, e nao a memoria — o
#:      fork entrega a memoria por acidente e torna a garantia
#:      inverificavel;
#:   2. uma conexao SQLite usada depois de um fork e comportamento
#:      indefinido, e o proprio SQLite documenta isso;
#:   3. a linguagem passava a responder DUAS coisas conforme o sistema:
#:      no macOS ela recusava o recurso que nao atravessa, e no Linux
#:      seguia calada. 'test_o_recurso_que_a_acao_usa_e_acusado_pelo_NOME'
#:      falhava so no ubuntu, e o motivo nao estava em lugar nenhum.
#:
#: O preco e a partida: 'spawn' sobe um Python novo. A travessia ja
#: pagava isso por desenho — o filho remonta tudo num interpretador
#: proprio —, e 'P.pool_processos()' existe para pagar uma vez.
#: O contexto, decidido uma vez: 'get_context' e barato, mas o
#: 'set_forkserver_preload' nao deve ser refeito a cada chamada.
_CONTEXTO = None


def _contexto():
    """Como o processo filho nasce — e por que nao e 'fork'.

    **'fork' esta fora.** Ele entrega ao filho a memoria do pai, e com
    ela uma conexao SQLite que chega "funcionando" sem ter passado por
    'travessia.py'. O resultado era a linguagem respondendo DUAS coisas
    conforme o sistema: no Linux o filho usava a conexao herdada, no
    macOS o mesmo programa acusava o recurso pelo nome. Usar uma
    conexao SQLite depois de um fork e comportamento indefinido, dito
    pelo proprio SQLite.

    **'forkserver' e o certo onde existe.** Um servidor e iniciado
    limpo (sem a memoria do pai), importa o 'dataforge' UMA vez por
    causa do 'preload', e cada trabalhador sai de um fork dele — a
    correcao do spawn com o custo de partida do fork.

    A diferenca e medida, e nao teorica: com 'spawn', todo trabalhador
    importa o interpretador inteiro, e num bloco pequeno a partida
    COME o ganho. O CI do Linux entregou 1,2x a 1,4x onde esta maquina
    dava 2,4x, e o Windows — que so tem spawn — 1,02x.

    **O Windows fica com 'spawn'**, que e o unico metodo que ele tem.
    """
    global _CONTEXTO
    if _CONTEXTO is not None:
        return _CONTEXTO
    import multiprocessing
    if "forkserver" in multiprocessing.get_all_start_methods():
        ctx = multiprocessing.get_context("forkserver")
        try:
            # O import do interpretador acontece no servidor, e nao em
            # cada trabalhador.
            ctx.set_forkserver_preload(["dataforge"])
        except (AttributeError, ValueError):       # pragma: no cover
            pass
    else:
        ctx = multiprocessing.get_context("spawn")
    _CONTEXTO = ctx
    return ctx


PADRAO_PROCESSOS = os.cpu_count() or 4


def _exigir_main_importavel():
    """O filho IMPORTA o programa principal. Ele precisa ser um arquivo.

    Nem 'spawn' nem 'forkserver' copiam a memoria do pai: o filho
    reconstroi o estado importando o modulo '__main__'. Quando o
    programa foi alimentado pela ENTRADA PADRAO ('python3 - < prog.py',
    ou um heredoc), esse modulo se chama '<stdin>' e nao existe em
    disco — o trabalhador morre no import, e a mensagem que sobra e
    'a worker process died', que nao diz nada sobre a causa.

    'dataforge run arquivo.df', 'python -m dataforge' e 'python -c'
    todos passam por aqui sem reclamar: os tres tem um '__main__' que o
    filho consegue importar.
    """
    principal = sys.modules.get("__main__")
    arquivo = getattr(principal, "__file__", None)
    if arquivo is None or os.path.isfile(arquivo):
        return
    raise ConcurrencyError(
        "processes need a main program that can be imported, and this one "
        f"came from {arquivo!r}.",
        nota="a child process rebuilds its state by importing '__main__' — "
             "it does not inherit the parent's memory",
        dica="save the program to a file and run it with "
             "'dataforge run arquivo.df'",
        doc="tecnicas/concorrencia")


def _traduzir_erro_do_filho(e):
    """O erro que aconteceu no outro processo, de volta como erro daqui.

    A pilha, a linha de codigo e o arquivo ficam do outro lado — nada
    disso sobrevive a copia. O que volta e a mensagem ja montada, e ela
    diz ONDE aconteceu: sem isso, um erro de uma acao que roda em oito
    processos parece ter acontecido na linha do 'map_processos', que e
    a unica linha que este processo executou.
    """
    from ..errors import DataForgeError

    classes = {c.__name__: c for c in _descendentes(DataForgeError)}
    classe = classes.get(e.tipo) or classes.get(e.tipo + "_") or RuntimeError_
    nota = e.nota or ""
    aviso = "this happened inside another process, started by 'map_processos'"
    return classe(e.texto, nota=(nota + "\n" + aviso) if nota else aviso,
                  dica=e.dica, doc="tecnicas/concorrencia")


def _descendentes(classe):
    yield classe
    for filha in classe.__subclasses__():
        yield from _descendentes(filha)


class Tarefa:
    """Uma linha de execucao com resultado.

    O 'thread' da linguagem dispara e esquece. Isto lembra: guarda o
    que a acao devolveu, guarda o erro se houve, e 'esperar()' entrega
    um ou levanta o outro.
    """

    __slots__ = ("_futuro", "nome", "_inicio")

    def __init__(self, futuro, nome=""):
        self._futuro = futuro
        self.nome = nome
        self._inicio = time.perf_counter()

    def esperar(self, prazo=None):
        """O resultado. Levanta aqui o erro que aconteceu la dentro.

        Sem isto, uma excecao numa thread some — ela morre no
        interpretador de threads e o programa segue como se tudo
        tivesse dado certo. E o modo mais silencioso de perder dado.
        """
        try:
            return self._futuro.result(timeout=prazo)
        except futuros.TimeoutError:
            raise TimeoutError_(
                f"the task {self.nome or ''} did not finish in {prazo}s.",
                dica="raise the deadline, or cancel it with 'cancelar'",
                doc="tecnicas/concorrencia") from None

    def pronta(self):
        return self._futuro.done()

    def cancelar(self):
        """Cancela — se ela ainda nao comecou.

        Uma thread que ja esta rodando nao pode ser interrompida de
        fora sem risco de deixar o estado pela metade. Python nao
        oferece isso, e fingir que oferece seria pior.
        """
        return self._futuro.cancel()

    def erro(self):
        """O erro, sem levanta-lo. None se deu certo ou ainda roda."""
        if not self._futuro.done():
            return None
        return self._futuro.exception()

    def duracao(self):
        return round(time.perf_counter() - self._inicio, 6)

    def __repr__(self):
        estado = "pronta" if self.pronta() else "rodando"
        return f"<tarefa {self.nome or '?'} {estado}>"


class TarefaDeProcesso(Tarefa):
    """Uma tarefa que roda em OUTRO processo.

    Ela existe porque o que atravessa a fronteira e codificado: o
    resultado precisa ser traduzido de volta com a tabela de
    declaracoes deste processo, e o erro precisa deixar de falar do
    outro lado antes de chegar a quem escreveu.
    """

    __slots__ = ("_empacotador",)

    def __init__(self, futuro, empacotador, nome=""):
        super().__init__(futuro, nome)
        self._empacotador = empacotador

    def esperar(self, prazo=None):
        from ..travessia import _ErroDoFilho, desempacotar
        try:
            cru = super().esperar(prazo)
        except _ErroDoFilho as e:
            raise _traduzir_erro_do_filho(e) from None
        return desempacotar(self._empacotador, cru)


class PoolDeProcessos:
    """Processos que ficam de pe entre uma chamada e a proxima.

    'map_processos' abre um pool, usa e fecha. Iniciar um processo
    custa mais de cem milissegundos — aceitavel uma vez num script,
    inaceitavel por pedido num servidor web. Um pool aberto no comeco
    do programa paga isso uma vez.

    O preco e simetrico: os processos ficam vivos ate 'fechar()'. Por
    isso ele e explicito, e nao automatico — um pool aberto por engano
    dentro de um laco deixaria a maquina cheia de processos ociosos.
    """

    __slots__ = ("_pool", "trabalhadores", "_fechado")

    def __init__(self, trabalhadores=None):
        _exigir_main_importavel()
        self.trabalhadores = trabalhadores or PADRAO_PROCESSOS
        self._pool = futuros.ProcessPoolExecutor(
            max_workers=self.trabalhadores, mp_context=_contexto())
        self._fechado = False

    def _conferir(self):
        if self._fechado:
            raise ConcurrencyError(
                "this pool is closed.",
                nota="'fechar()' ends the processes, and they do not "
                     "come back",
                dica="open another with 'P.pool_processos()', or close it "
                     "only when the program is ending",
                doc="tecnicas/concorrencia")

    def map(self, acao, itens, lote=None):
        """A acao sobre cada item, nos processos ja abertos."""
        self._conferir()
        lista = list(itens)
        if not lista:
            return []
        pacote, traduzidos, emp = _empacotar_ou_explicar(acao, lista)
        from ..travessia import Chamada, desempacotar
        tamanho = lote or max(1, len(lista) // (self.trabalhadores * 4))
        crus = self._colher(
            lambda: list(self._pool.map(Chamada(pacote.marca, pacote),
                                        traduzidos, chunksize=tamanho)))
        return [desempacotar(emp, x) for x in crus]

    def enviar(self, acao, *args):
        """Dispara UMA chamada num processo e devolve a tarefa.

        E o 'thread' da linguagem, num nucleo de verdade: dispara e
        segue, e 'esperar()' entrega o resultado quando ele vier.
        """
        self._conferir()
        pacote, traduzidos, emp = _empacotar_ou_explicar(acao, list(args))
        from ..travessia import Chamada
        futuro = self._pool.submit(Chamada(pacote.marca, pacote),
                                   traduzidos[0] if traduzidos else None)
        return TarefaDeProcesso(futuro, emp, getattr(acao, "name", ""))

    def fechar(self, esperar=True):
        """Encerra os processos. Depois disto o pool nao serve mais."""
        if not self._fechado:
            self._pool.shutdown(wait=esperar)
            self._fechado = True
        return True

    def aberto(self):
        return not self._fechado

    def _colher(self, acao):
        try:
            return acao()
        except _ErroDoFilho as e:
            raise _traduzir_erro_do_filho(e) from None
        except futuros.process.BrokenProcessPool as e:
            self._fechado = True
            raise ConcurrencyError(
                f"a worker process died: {e}",
                nota="the pool cannot be reused after this — a broken "
                     "pool refuses everything that comes next",
                dica="open another with 'P.pool_processos()', and check "
                     "for memory that grows per item",
                doc="tecnicas/concorrencia") from None

    def __repr__(self):
        estado = "aberto" if self.aberto() else "fechado"
        return f"<pool de {self.trabalhadores} processos, {estado}>"


def _empacotar_ou_explicar(acao, itens):
    """Empacota, e traduz a recusa para o vocabulario de quem escreve."""
    from ..travessia import NaoAtravessa, empacotar

    try:
        return empacotar(acao, itens)
    except NaoAtravessa as e:
        raise ConcurrencyError(
            f"this action cannot cross into another process: {e.mensagem}",
            nota=e.nota or ("a process receives the data by copy, and what "
                            "exists only in this process cannot be copied"),
            dica=e.dica or ("pass what the action needs as arguments — or "
                            "use 'map', which uses threads and shares "
                            "memory"),
            doc="tecnicas/concorrencia") from None


class Grupo:
    """Um conjunto de tarefas que se espera junto.

    A alternativa — guardar as tarefas num cluster e esperar uma a uma
    — funciona ate uma falhar: as outras continuam rodando, e o
    programa termina com threads soltas escrevendo em arquivos que
    ninguem mais le.
    """

    def __init__(self, trabalhadores=None, nome=""):
        self.nome = nome
        self._pool = futuros.ThreadPoolExecutor(
            max_workers=trabalhadores or PADRAO_THREADS,
            thread_name_prefix=nome or "df")
        self._tarefas = []

    def rodar(self, acao, *args):
        t = Tarefa(self._pool.submit(acao, *args), getattr(acao, "name", ""))
        self._tarefas.append(t)
        return t

    def esperar_todas(self, prazo=None):
        """Todos os resultados, na ordem em que foram disparadas.

        Se alguma falhou, o erro sobe — depois de esperar as outras.
        Subir na hora deixaria as demais rodando sem dono.
        """
        resultados, primeiro_erro = [], None
        for t in self._tarefas:
            try:
                resultados.append(t.esperar(prazo))
            except BaseException as e:              # noqa: BLE001
                resultados.append(None)
                if primeiro_erro is None:
                    primeiro_erro = e
        if primeiro_erro is not None:
            raise primeiro_erro
        return resultados

    def resultados(self):
        """O que deu certo e o que deu errado, sem levantar nada."""
        saida = []
        for t in self._tarefas:
            if not t.pronta():
                saida.append({"estado": "rodando", "valor": None, "erro": ""})
            elif t.erro() is not None:
                saida.append({"estado": "erro", "valor": None,
                              "erro": str(t.erro())})
            else:
                saida.append({"estado": "ok", "valor": t.esperar(),
                              "erro": ""})
        return saida

    def fechar(self, esperar=True):
        self._pool.shutdown(wait=esperar)
        return len(self._tarefas)

    def __enter__(self):
        return self

    def __exit__(self, *_):
        self.fechar()
        return False


class Canal:
    """Uma fila entre threads, com espera de verdade.

    O 'channel' da linguagem devolve void na hora quando a fila esta
    vazia — o consumidor precisa girar num laco perguntando, o que
    queima CPU e ainda perde mensagem por corrida.

    Aqui 'receber' BLOQUEIA ate haver algo, com prazo opcional. E o
    que faz um produtor/consumidor funcionar sem laco de espera.
    """

    def __init__(self, capacidade=0):
        self._fila = queue.Queue(maxsize=capacidade if capacidade > 0 else 0)
        self._fechado = threading.Event()

    def enviar(self, valor, prazo=None):
        if self._fechado.is_set():
            raise ConcurrencyError(
                "this channel is closed.",
                dica="check with 'aberto()' before sending",
                doc="tecnicas/concorrencia")
        try:
            self._fila.put(valor, timeout=prazo)
            return True
        except queue.Full:
            raise TimeoutError_(
                f"the channel is full and did not free up in {prazo}s.",
                dica="raise the capacity, or consume faster",
                doc="tecnicas/concorrencia") from None

    def receber(self, prazo=None):
        """Espera ate chegar algo. Devolve void quando o canal fecha."""
        while True:
            try:
                return self._fila.get(timeout=prazo if prazo else 0.05)
            except queue.Empty:
                if self._fechado.is_set() and self._fila.empty():
                    return None
                if prazo is not None:
                    raise TimeoutError_(
                        f"nothing arrived in {prazo}s.",
                        dica="raise the deadline, or check whether the "
                             "producer is still running",
                        doc="tecnicas/concorrencia") from None

    def tentar_receber(self):
        """Sem esperar: devolve void se estiver vazio."""
        try:
            return self._fila.get_nowait()
        except queue.Empty:
            return None

    def fechar(self):
        """Fecha. Quem espera recebe void e sai do laco."""
        self._fechado.set()
        return True

    def aberto(self):
        return not self._fechado.is_set()

    def tamanho(self):
        return self._fila.qsize()

    def vazio(self):
        return self._fila.empty()

    def __iter__(self):
        """'cycle item in canal' consome ate o canal fechar."""
        while True:
            item = self.receber()
            if item is None and self._fechado.is_set():
                return
            if item is not None:
                yield item


class Atomico:
    """Um valor com troca condicional — o CAS.

    A diferenca para o `Contador`: ele guarda QUALQUER valor, e a peca
    central e `comparar_e_trocar`, que so escreve se o valor ainda for o
    que quem chamou leu. E com ela que se escreve um contador sem trava,
    uma pilha sem trava e um pedaco de STM.

    Sobre "sem trava" aqui: a trava existe e e curta. No CPython, o que
    torna a operacao indivisivel de verdade e o GIL — e uma peca que
    prometesse ausencia de trava sem poder garanti-la seria pior que uma
    que diz onde ela esta.
    """

    __slots__ = ("_valor", "_trava")

    def __init__(self, inicial=None):
        self._valor = inicial
        self._trava = threading.Lock()

    def pegar(self):
        with self._trava:
            return self._valor

    def definir(self, novo):
        with self._trava:
            self._valor = novo
            return novo

    def trocar(self, novo):
        """Escreve e devolve o valor ANTERIOR."""
        with self._trava:
            anterior, self._valor = self._valor, novo
            return anterior

    def comparar_e_trocar(self, esperado, novo):
        """Troca so se o valor ainda for o esperado. Devolve se trocou."""
        with self._trava:
            if self._valor is esperado or self._valor == esperado:
                self._valor = novo
                return True
            return False

    def somar(self, quanto=1):
        """Soma e devolve o NOVO valor — o 'fetch-add' com a ordem certa."""
        with self._trava:
            self._valor += quanto
            return self._valor

    def pegar_e_somar(self, quanto=1):
        """Soma e devolve o valor ANTERIOR."""
        with self._trava:
            anterior = self._valor
            self._valor += quanto
            return anterior

    def atualizar(self, acao):
        """Aplica a acao ao valor, repetindo enquanto alguem trocar."""
        while True:
            atual = self.pegar()
            novo = acao(atual)
            if self.comparar_e_trocar(atual, novo):
                return novo

    def __repr__(self):                                    # pragma: no cover
        return f"<atomico {self._valor!r}>"


class FilaSemTrava:
    """Uma fila entre threads sem trava no caminho comum.

    O `deque` do Python tem `append` e `popleft` indivisiveis por causa
    do GIL — nao ha janela entre ler e escrever, porque a operacao
    inteira acontece em C. E o mesmo raciocinio ja medido no
    repositorio: quatro threads com 5 mil `append` cada entregaram
    20.000 de 20.000.
    """

    __slots__ = ("_itens",)

    def __init__(self, itens=None):
        from collections import deque
        self._itens = deque(itens or [])

    def por(self, item):
        self._itens.append(item)
        return item

    def tirar(self):
        """O primeiro, ou `void` quando vazia. Nunca bloqueia."""
        try:
            return self._itens.popleft()
        except IndexError:
            return None

    def espiar(self):
        try:
            return self._itens[0]
        except IndexError:
            return None

    def tamanho(self):
        return len(self._itens)

    def vazia(self):
        return not self._itens

    def tudo(self):
        return list(self._itens)


class PilhaSemTrava:
    """Pilha com o mesmo raciocinio da fila: `append`/`pop` no fim."""

    __slots__ = ("_itens",)

    def __init__(self, itens=None):
        from collections import deque
        self._itens = deque(itens or [])

    def por(self, item):
        self._itens.append(item)
        return item

    def tirar(self):
        try:
            return self._itens.pop()
        except IndexError:
            return None

    def espiar(self):
        try:
            return self._itens[-1]
        except IndexError:
            return None

    def tamanho(self):
        return len(self._itens)

    def vazia(self):
        return not self._itens

    def tudo(self):
        return list(self._itens)


class Anel:
    """Um buffer circular de tamanho fixo: o mais velho sai quando enche.

    E a estrutura de uma janela de metricas, de um log em memoria e de
    um produtor rapido com consumidor lento — onde perder o mais VELHO e
    melhor que parar o produtor.
    """

    __slots__ = ("_itens", "_capacidade")

    def __init__(self, capacidade=16):
        from collections import deque
        self._capacidade = max(1, int(capacidade))
        self._itens = deque(maxlen=self._capacidade)

    def por(self, item):
        """Guarda. Devolve o que saiu, ou `void` se nao saiu nada."""
        saiu = self._itens[0] if len(self._itens) == self._capacidade else None
        self._itens.append(item)
        return saiu

    def tirar(self):
        try:
            return self._itens.popleft()
        except IndexError:
            return None

    def tudo(self):
        return list(self._itens)

    def tamanho(self):
        return len(self._itens)

    def capacidade(self):
        return self._capacidade

    def cheio(self):
        return len(self._itens) == self._capacidade

    def vazio(self):
        return not self._itens


class Executor:
    """Um grupo de threads que fica de pe e recebe trabalho.

    `rodar` abre uma thread por chamada; num servidor isso acontece por
    pedido. O executor paga a partida uma vez.
    """

    __slots__ = ("_pool", "_trabalhadores", "_aberto")

    def __init__(self, trabalhadores=4):
        self._trabalhadores = max(1, int(trabalhadores))
        self._pool = futuros.ThreadPoolExecutor(max_workers=self._trabalhadores)
        self._aberto = True

    def submeter(self, acao, *args):
        self._exigir_aberto()
        return Tarefa(self._pool.submit(acao, *args),
                      getattr(acao, "name", ""))

    def mapear(self, acao, itens):
        self._exigir_aberto()
        return list(self._pool.map(acao, list(itens)))

    def trabalhadores(self):
        return self._trabalhadores

    def aberto(self):
        return self._aberto

    def fechar(self, esperar=True):
        if not self._aberto:
            return False
        self._aberto = False
        self._pool.shutdown(wait=bool(esperar))
        return True

    def _exigir_aberto(self):
        if not self._aberto:
            raise ConcurrencyError(
                "este executor ja foi fechado.", 0, 0,
                dica="abra outro com C.executor(n)",
                doc="concorrencia/sem-trava")


class Promessa:
    """Um resultado que ainda nao existe, e que ALGUEM vai cumprir.

    A diferenca para a tarefa: a tarefa nasce de um trabalho que ja
    comecou; a promessa nasce vazia, e quem a cumpre pode ser outra
    parte do programa — um evento, uma resposta de rede, um clique.
    """

    __slots__ = ("_futuro",)

    def __init__(self):
        self._futuro = futuros.Future()

    def cumprir(self, valor=None):
        if self._futuro.done():
            return False
        self._futuro.set_result(valor)
        return True

    def falhar(self, motivo="falhou"):
        if self._futuro.done():
            return False
        self._futuro.set_exception(
            RuntimeError_(str(motivo), 0, 0, doc="concorrencia/sem-trava"))
        return True

    def cumprida(self):
        return self._futuro.done()

    def esperar(self, prazo=None):
        try:
            return self._futuro.result(prazo / 1000 if prazo else None)
        except futuros.TimeoutError:
            raise TimeoutError_(
                "a promessa nao foi cumprida no prazo.", 0, 0,
                doc="concorrencia/sem-trava") from None

    def tarefa(self):
        """A mesma espera, como Tarefa — para usar com 'esperar_todas'."""
        return Tarefa(self._futuro, "promessa")


class Contador:
    """Um numero que varias threads somam sem perder atualizacao.

    'x := x + 1' em duas threads perde uma das somas: as duas leem o
    mesmo valor antes de qualquer uma gravar. Com a trava, nao.
    """

    __slots__ = ("_valor", "_trava")

    def __init__(self, inicial=0):
        self._valor = inicial
        self._trava = threading.Lock()

    def somar(self, quanto=1):
        with self._trava:
            self._valor += quanto
            return self._valor

    def subtrair(self, quanto=1):
        return self.somar(-quanto)

    def valor(self):
        with self._trava:
            return self._valor

    def zerar(self):
        with self._trava:
            anterior, self._valor = self._valor, 0
            return anterior


class ArcaneConcurrent(dict):
    """Threads, processos, travas e canais."""

    def __new__(cls):
        return {
            # ── disparar ──
            "rodar": cls._rodar,
            "grupo": cls._grupo,
            "esperar": cls._esperar,
            "esperar_todas": cls._esperar_todas,
            "esperar_primeira": cls._esperar_primeira,

            # ── mapear ──
            "map": cls._map,
            "map_processos": cls._map_processos,
            "pool_processos": cls._pool_processos,
            "processo": cls._processo,
            "para_cada": cls._para_cada,
            "lotes": cls._lotes,

            # ── sincronizacao ──
            "mutex": cls._mutex,
            "com_trava": cls._com_trava,
            "semaforo": cls._semaforo,
            "evento": cls._evento,
            "barreira": cls._barreira,
            "condicao": cls._condicao,
            "contador": cls._contador,
            "atomico": cls._atomico,
            "fila_sem_trava": cls._fila_sem_trava,
            "pilha_sem_trava": cls._pilha_sem_trava,
            "anel": cls._anel,
            "executor": cls._executor,
            "promessa": cls._promessa,
            "trava_leitura_escrita": cls._rwlock,

            # ── canal ──
            "canal": cls._canal,

            # ── informacao ──
            "nucleos": lambda: os.cpu_count() or 1,
            "thread_atual": cls._thread_atual,
            "threads_vivas": lambda: threading.active_count(),
            "sou_principal": cls._sou_principal,

            # ── tempo ──
            "dormir": cls._dormir,
            "com_prazo": cls._com_prazo,
            "repetir_a_cada": cls._repetir_a_cada,
        }

    # ── disparar ────────────────────────────────────────────

    @staticmethod
    def _rodar(acao, *args):
        """Dispara numa thread e devolve a tarefa."""
        pool = futuros.ThreadPoolExecutor(max_workers=1)
        tarefa = Tarefa(pool.submit(acao, *args), getattr(acao, "name", ""))
        # O pool se desmonta quando a tarefa termina; sem isto, cada
        # 'rodar' deixaria uma thread ociosa viva ate o fim do programa.
        pool.shutdown(wait=False)
        return tarefa

    @staticmethod
    def _grupo(trabalhadores=None, nome=""):
        return Grupo(trabalhadores, nome)

    @staticmethod
    def _exigir_tarefa(valor, funcao, indice=None):
        """Recusa quem nao veio de 'rodar', com a mensagem certa.

        Passar a ACAO em vez da TAREFA e o engano natural: 'map' e
        'para_cada' recebem acoes, e estes recebem tarefas. Sem esta
        checagem o erro era "'DFAction' object has no attribute
        'esperar'" — o nome de uma classe interna do interpretador,
        que nao diz nada a quem escreve DataForge.
        """
        if isinstance(valor, Tarefa):
            return valor
        onde = "" if indice is None else f" (o item {indice} da lista)"
        if callable(valor):
            raise TypeError_(
                f"{funcao} espera uma tarefa, e recebeu uma acao{onde}.",
                nota="uma acao so vira tarefa depois de ser disparada",
                dica=("dispare antes:  t := Concurrent.rodar(acao)  e entao "
                      f"{funcao}(t)\n"
                      "para rodar a acao sobre varios itens de uma vez, use "
                      "'map' ou 'para_cada'"),
                doc="tecnicas/concorrencia")
        raise TypeError_(
            f"{funcao} espera uma tarefa, e recebeu {_nome_do_tipo(valor)}{onde}.",
            dica="uma tarefa vem de 'rodar', de 'grupo.enviar' ou de 'lotes'",
            doc="tecnicas/concorrencia")

    @staticmethod
    def _esperar(tarefa, prazo=None):
        return ArcaneConcurrent._exigir_tarefa(tarefa, "esperar").esperar(prazo)

    @staticmethod
    def _esperar_todas(tarefas, prazo=None):
        return [ArcaneConcurrent._exigir_tarefa(t, "esperar_todas", i).esperar(prazo)
                for i, t in enumerate(tarefas)]

    @staticmethod
    def _esperar_primeira(tarefas, prazo=None):
        """O primeiro resultado que chegar; as outras seguem rodando."""
        pendentes = [
            ArcaneConcurrent._exigir_tarefa(t, "esperar_primeira", i)._futuro
            for i, t in enumerate(tarefas)]
        prontas, _ = futuros.wait(
            pendentes, timeout=prazo, return_when=futuros.FIRST_COMPLETED)
        if not prontas:
            raise TimeoutError_(
                f"none of the {len(tarefas)} tasks finished in {prazo}s.",
                doc="tecnicas/concorrencia")
        return next(iter(prontas)).result()

    # ── mapear ──────────────────────────────────────────────

    @staticmethod
    def _map(acao, itens, trabalhadores=None, prazo=None):
        """A acao sobre cada item, em paralelo, NA ORDEM da entrada.

        A ordem importa: um resultado fora de ordem obriga quem chama
        a reassociar item e resultado, e e ai que se erra.

        Use para trabalho que ESPERA — rede, disco, banco. Para
        trabalho que calcula, veja 'map_processos'.
        """
        lista = list(itens)
        if not lista:
            return []
        n = trabalhadores or min(PADRAO_THREADS, len(lista))
        with futuros.ThreadPoolExecutor(max_workers=n) as pool:
            return list(pool.map(acao, lista, timeout=prazo))

    @staticmethod
    def _map_processos(acao, itens, trabalhadores=None):
        """Igual, mas em PROCESSOS — para trabalho que calcula.

        Duas threads Python nunca executam bytecode ao mesmo tempo (o
        GIL). Para calculo, oito threads levam o mesmo tempo que uma;
        so processos usam os oito nucleos.

        O que atravessa nao e a acao: e a DECLARACAO dela, mais os
        nomes que ela le e nao cria. Copiar a acao era impossivel — o
        fechamento dela alcanca o escopo global, e la moram modulos e
        funcoes anonimas que o pickle nao copia. Ver 'travessia.py'.

        O custo e serializar os dados de ida e volta: vale a partir de
        alguns milissegundos de trabalho por item.
        """
        lista = list(itens)
        if not lista:
            return []

        from ..travessia import Chamada, desempacotar, instalar

        pacote, traduzidos, emp = _empacotar_ou_explicar(acao, lista)

        n = trabalhadores or min(PADRAO_PROCESSOS, len(lista))
        # Lotes grandes o bastante para o custo de atravessar a
        # fronteira nao dominar, e pequenos o bastante para o ultimo
        # processo nao ficar com todo o resto: quatro lotes por
        # trabalhador e o meio termo usual.
        lote = max(1, len(lista) // (n * 4))
        _exigir_main_importavel()
        try:
            with futuros.ProcessPoolExecutor(
                    max_workers=n, initializer=instalar,
                    initargs=(pacote,), mp_context=_contexto()) as pool:
                crus = list(pool.map(Chamada(pacote.marca), traduzidos,
                                     chunksize=lote))
        except _ErroDoFilho as e:
            raise _traduzir_erro_do_filho(e) from None
        except futuros.process.BrokenProcessPool as e:
            raise ConcurrencyError(
                f"a worker process died: {e}",
                nota="the action was interrupted in the middle — a "
                     "process that dies takes no error message with it",
                dica="check for memory use that grows per item, and for "
                     "a library that calls into C code",
                doc="tecnicas/concorrencia") from None

        return [desempacotar(emp, x) for x in crus]

    @staticmethod
    def _pool_processos(trabalhadores=None):
        """Processos que ficam de pe entre uma chamada e a proxima.

        Iniciar um processo custa mais de cem milissegundos. Num
        script isso acontece uma vez; num servidor, a cada pedido —
        e ai a conta nao fecha. Um pool aberto no comeco paga o custo
        uma vez so.

            pool := P.pool_processos()
            out pool.map(pesado, blocos)
            pool.fechar()
        """
        return PoolDeProcessos(trabalhadores)

    @staticmethod
    def _processo(acao, *args):
        """Dispara UMA chamada em outro processo e devolve a tarefa.

        E o 'thread' da linguagem num nucleo de verdade: dispara e
        segue. Para varias chamadas seguidas, abra um pool — este
        abre e fecha um processo por chamada.
        """
        pool = PoolDeProcessos(1)
        tarefa = pool.enviar(acao, *args)
        # O pool fecha SEM esperar: 'shutdown(wait=False)' nao mata o
        # que ja foi enviado, e sem ele o processo ficaria vivo depois
        # de a tarefa terminar — um por chamada, ate o programa sair.
        pool._pool.shutdown(wait=False)
        return tarefa

    @staticmethod
    def _para_cada(acao, itens, trabalhadores=None):
        """Como 'map', mas descarta o resultado — e nao levanta no meio.

        Devolve quantas deram certo e quantas falharam. Para efeito
        colateral em lote — enviar e-mails, gravar arquivos — parar na
        primeira falha costuma ser pior que seguir e relatar.
        """
        lista = list(itens)
        if not lista:
            return {"ok": 0, "erros": []}
        n = trabalhadores or min(PADRAO_THREADS, len(lista))
        ok, erros = 0, []
        with futuros.ThreadPoolExecutor(max_workers=n) as pool:
            enviados = {pool.submit(acao, item): item for item in lista}
            for f in futuros.as_completed(enviados):
                if f.exception() is None:
                    ok += 1
                else:
                    erros.append({"item": enviados[f],
                                  "erro": str(f.exception())})
        return {"ok": ok, "erros": erros}

    @staticmethod
    def _lotes(acao, itens, tamanho=10, trabalhadores=None):
        """Processa em lotes: a acao recebe uma LISTA por vez.

        Para trabalho com custo fixo por chamada — uma consulta ao
        banco, uma chamada de API — mil itens em lotes de cem custam
        dez chamadas em vez de mil.
        """
        lista = list(itens)
        pedacos = [lista[i:i + tamanho]
                   for i in range(0, len(lista), max(1, tamanho))]
        return ArcaneConcurrent._map(acao, pedacos, trabalhadores)

    # ── sincronizacao ───────────────────────────────────────

    @staticmethod
    def _mutex():
        """Uma trava: so uma thread por vez passa.

        Reentrante de proposito. A nao reentrante trava o programa
        quando uma acao com trava chama outra com a MESMA trava — e
        isso acontece por engano com facilidade.
        """
        return threading.RLock()

    @staticmethod
    def _com_trava(trava, acao):
        """Roda a acao com a trava tomada, e a solta mesmo com erro.

        Tomar e soltar a mao funciona ate o corpo estourar: ai a trava
        fica tomada para sempre, e a proxima thread espera eternamente.
        """
        with trava:
            return acao()

    @staticmethod
    def _semaforo(quantos=1):
        """Deixa passar N ao mesmo tempo, e nao uma.

        E o que limita concorrencia contra um recurso externo: cinco
        conexoes simultaneas ao banco, tres chamadas por vez a uma API
        com limite.
        """
        return threading.Semaphore(max(1, quantos))

    @staticmethod
    def _evento():
        """Um sinal de 'pode ir', que varias threads esperam."""
        return threading.Event()

    @staticmethod
    def _barreira(quantas):
        """Segura todas ate a ultima chegar, e ai libera juntas."""
        return threading.Barrier(max(1, quantas))

    @staticmethod
    def _condicao():
        """Espera ate uma condicao mudar, sem girar perguntando."""
        return threading.Condition()

    @staticmethod
    def _contador(inicial=0):
        return Contador(inicial)

    @staticmethod
    def _atomico(inicial=None):
        """Um valor com troca condicional (CAS) e soma indivisivel."""
        return Atomico(inicial)

    @staticmethod
    def _fila_sem_trava(itens=None):
        return FilaSemTrava(itens)

    @staticmethod
    def _pilha_sem_trava(itens=None):
        return PilhaSemTrava(itens)

    @staticmethod
    def _anel(capacidade=16):
        return Anel(capacidade)

    @staticmethod
    def _executor(trabalhadores=4):
        return Executor(trabalhadores)

    @staticmethod
    def _promessa():
        return Promessa()

    @staticmethod
    def _rwlock():
        """Muitos leem juntos; quem escreve espera todos sairem.

        Para dado lido com frequencia e escrito raramente — um cache,
        uma configuracao — um mutex comum serializa leituras que
        poderiam acontecer juntas.
        """
        return _TravaLeituraEscrita()

    # ── canal ───────────────────────────────────────────────

    @staticmethod
    def _canal(capacidade=0):
        """Uma fila entre threads. 'receber' ESPERA ate chegar algo.

        Com capacidade, o produtor tambem espera quando ela enche — e
        e assim que se evita um produtor rapido estourar a memoria
        contra um consumidor lento.
        """
        return Canal(capacidade)

    # ── informacao ──────────────────────────────────────────

    @staticmethod
    def _thread_atual():
        t = threading.current_thread()
        return {"nome": t.name, "id": t.ident, "principal": t is threading.main_thread()}

    @staticmethod
    def _sou_principal():
        return threading.current_thread() is threading.main_thread()

    # ── tempo ───────────────────────────────────────────────

    @staticmethod
    def _dormir(segundos):
        time.sleep(max(0.0, float(segundos)))
        return True

    @staticmethod
    def _com_prazo(acao, segundos):
        """Roda com prazo. Estoura TimeoutError se passar.

        A acao NAO e interrompida — Python nao permite matar uma
        thread de fora sem risco de deixar estado pela metade. Ela
        segue rodando em segundo plano; o que o prazo garante e que
        QUEM CHAMOU nao fica preso.
        """
        pool = futuros.ThreadPoolExecutor(max_workers=1)
        try:
            f = pool.submit(acao)
            return f.result(timeout=segundos)
        except futuros.TimeoutError:
            raise TimeoutError_(
                f"it did not finish in {segundos}s.",
                nota="the action keeps running in the background: Python "
                     "cannot kill a thread from outside safely",
                dica="raise the deadline, or make the action check a flag",
                doc="tecnicas/concorrencia") from None
        finally:
            pool.shutdown(wait=False)

    @staticmethod
    def _repetir_a_cada(acao, segundos, vezes=0):
        """Roda a cada N segundos, numa thread. Devolve como parar.

        O intervalo conta a partir do FIM da execucao anterior: se a
        acao demora mais que o intervalo, as execucoes nao se
        empilham.
        """
        parar = threading.Event()
        contagem = {"n": 0, "falhas": 0, "ultimo_erro": None}
        ja_avisados = set()

        def laco():
            while not parar.is_set():
                if vezes and contagem["n"] >= vezes:
                    return
                try:
                    acao()
                except Exception as erro:             # noqa: BLE001
                    # A repeticao SEGUE: uma tarefa periodica que morre na
                    # primeira falha de rede nao serve para nada. O que
                    # mudou e que o erro era 'except BaseException: pass'
                    # — uma limpeza agendada que falhava toda volta
                    # parecia uma limpeza que rodava.
                    #
                    # Cada mensagem DIFERENTE e avisada uma vez: a mesma
                    # falha a cada 100 ms inundaria o terminal e esconderia
                    # o resto. A contagem e o ultimo erro ficam no vault
                    # devolvido, para o programa perguntar.
                    mensagem = getattr(erro, "message", None) or str(erro)
                    contagem["falhas"] += 1
                    contagem["ultimo_erro"] = mensagem
                    if mensagem not in ja_avisados:
                        ja_avisados.add(mensagem)
                        import sys
                        print(f"[repetir_a_cada] a volta {contagem['n'] + 1} "
                              f"falhou, e a repeticao segue: {mensagem}",
                              file=sys.stderr, flush=True)
                contagem["n"] += 1
                parar.wait(segundos)

        t = threading.Thread(target=laco, daemon=True, name="repeticao")
        t.start()
        return {"parar": lambda: (parar.set(), True)[1],
                "vezes": lambda: contagem["n"],
                "falhas": lambda: contagem["falhas"],
                "ultimo_erro": lambda: contagem["ultimo_erro"],
                "viva": lambda: t.is_alive()}


class _TravaLeituraEscrita:
    """Muitos leitores, um escritor.

    O escritor espera os leitores sairem. Leitores que chegam depois
    de um escritor pedir a trava entram na fila atras dele — sem isso,
    um fluxo constante de leitura deixaria o escritor esperando para
    sempre.
    """

    def __init__(self):
        self._trava = threading.Condition()
        self._leitores = 0
        self._escritor = False
        self._escritores_esperando = 0

    def ler(self, acao):
        with self._trava:
            while self._escritor or self._escritores_esperando > 0:
                self._trava.wait()
            self._leitores += 1
        try:
            return acao()
        finally:
            with self._trava:
                self._leitores -= 1
                if self._leitores == 0:
                    self._trava.notify_all()

    def escrever(self, acao):
        with self._trava:
            self._escritores_esperando += 1
            while self._escritor or self._leitores > 0:
                self._trava.wait()
            self._escritores_esperando -= 1
            self._escritor = True
        try:
            return acao()
        finally:
            with self._trava:
                self._escritor = False
                self._trava.notify_all()
